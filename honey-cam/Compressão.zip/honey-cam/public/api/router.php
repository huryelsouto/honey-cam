<?php
// Define o cabeçalho de resposta como JSON
header('Content-Type: application/json');

// Obtenha a rota da URL
$request = $_SERVER['REQUEST_URI'];

// Remova query strings, se houver
$request = strtok($request, '?');

// Remove qualquer prefixo até a última barra antes da rota
$request = preg_replace('#^/api/router.php#', '', $request);

// Roteamento básico

switch ($request) {
    case '/':
        //mainRoute();
        break;
    case '/login':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            //loginPostRoute();
        } else {
            //loginRoute();
        }
        break;
    case '/logout':
        //logoutRoute();
        break;
    default:
        http_response_code(404);
        echo "404 Not Found";
        break;
}

// switch ($request) {
//     case '/login':
//         require __DIR__ . '/controllers/login.php';
//         break;

//     case '/register':
//         require __DIR__ . '/controllers/register.php';
//         break;

//     case '/profile':
//         require __DIR__ . '/controllers/profile.php';
//         break;

//     default:
//         // Resposta para rota não encontrada
//         echo json_encode(['error' => 'Rota não encontrada']);
//         http_response_code(404);
//         break;
// }
?>