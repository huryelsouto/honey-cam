<?php
// Verifica se os dados necessários foram enviados
if (isset($requestData['username']) && isset($requestData['password'])) {
    $username = $requestData['username'];
    $password = $requestData['password'];

    // Aqui você pode adicionar lógica de autenticação

    // Exemplo de resposta de sucesso
    echo json_encode([
        'message' => 'Loguei com sucesso!',
        'username' => $username
    ]);
} else {
    // Resposta de erro se os dados estiverem faltando
    echo json_encode(['error' => 'Parâmetros inválidos.']);
    http_response_code(400);
}
?>
