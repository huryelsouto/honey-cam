<?php
require_once '/api/services/sweetcam-services.php';
require_once '/api/services/user-services.php';

// Inicia a sessão
session_start();

// Variável para armazenar o momento em que o processo de login começou
$beginTimeOfLogin = 0;

// Rota principal que determina se o usuário será redirecionado para a visualização de vídeo ou imagem com base na configuração atual do serviço
function mainRoute()
{
    global $beginTimeOfLogin;

    // Obtém o tipo de mídia atual (vídeo ou imagem)
    $medium = getMedium();

    // Se a mídia for vídeo
    if ($medium === "video") {
        $config = array_merge(getCamVideoConfig(), getBrandConfig(), ["userName" => $_SESSION['username']]);
        include '/views/video.html';
    }
    // Se a mídia for imagem
    elseif ($medium === "picture") {
        // Configura o objeto de configuração para a visualização de imagem
        $config = array_merge(getCamPictureConfig(), getBrandConfig(), ["userName" => $_SESSION['username']]);
        // Renderiza a visualização de imagem passando as configurações
        include '/views/picture.html';
    }
}

// Rota para exibir a página de login
function loginRoute()
{
    include '/views/login.html';
}

// Rota para lidar com o processo de login
function loginPostRoute()
{
    http_response_code(404);
    global $beginTimeOfLogin;

    // Obtém a sessão atual
    $session = $_SESSION;
    // Obtém o limite de tentativas de login
    $loginLimit = getLoginLimit();

    // Se a contagem de tentativas de login não existir na sessão, define-a como 0 e armazena o momento atual
    if (!isset($session['loginTimes'])) {
        $_SESSION['loginTimes'] = 0;
        $beginTimeOfLogin = time();
    }

    // Obtém o momento atual
    $currentTime = time();

    // Se o tempo desde o início do processo de login for inferior a 60 segundos
    if ($currentTime - $beginTimeOfLogin <= 60) {
        // Incrementa a contagem de tentativas de login
        $_SESSION['loginTimes'] += 1;

        // Se a contagem de tentativas de login ultrapassar o limite
        if ($_SESSION['loginTimes'] > $loginLimit) {
            // Retorna uma resposta de erro indicando que o limite de tentativas de login foi atingido
            http_response_code(403);
            echo json_encode(["error" => "login request reached limit"]);
            return;
        }
    } else {
        // Se passou mais de 60 segundos desde o último início de login, redefine a contagem de tentativas de login como 1 e armazena o momento atual
        $_SESSION['loginTimes'] = 1;
        $beginTimeOfLogin = time();
    }

    // Verifica se os dados necessários foram enviados
    if (isset($_POST['username']) && isset($_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Obtém o hash da senha do usuário pelo nome de usuário
        $passwordHash = findUserPasswordHashByName($username);

        // Se não encontrar um hash de senha correspondente ao nome de usuário, retorna um erro de usuário não encontrado
        if (!$passwordHash) {
            http_response_code(404);
            echo json_encode(["error" => "user not found"]);
            return;
        }

        // Compara a senha fornecida com o hash de senha armazenado
        if (password_verify($password, $passwordHash)) {
            // Se as senhas corresponderem, armazena o nome de usuário na sessão e retorna uma mensagem de sucesso
            $_SESSION['username'] = $username;
            http_response_code(200);
            echo json_encode(["message" => "succeed"]);
        } else {
            // Se as senhas não corresponderem, retorna um erro de senha incorreta
            http_response_code(401);
            echo json_encode(["error" => "wrong password"]);
        }
    } else {
        // Resposta de erro se os dados estiverem faltando
        echo json_encode(['error' => 'Parâmetros inválidos.']);
        http_response_code(400);
    }
}

// Rota para efetuar logout
function logoutRoute()
{
    // Destroi a sessão do usuário
    session_destroy();
    // Redireciona para a página de login
    header("Location: /login");
    exit();
}
?>